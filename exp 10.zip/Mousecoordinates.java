import java.awt.event.*;
import javax.swing.*;

public class Mousecoordinates extends JFrame implements MouseMotionListener {

    JLabel label;

    Mousecoordinates() {

        label = new JLabel("Move Mouse");

        add(label);

        addMouseMotionListener(this);

        setTitle("Mouse Coordinates");
        setSize(400, 300);
        setLayout(null);

        label.setBounds(120, 120, 200, 30);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void mouseMoved(MouseEvent e) {
        label.setText("X = " + e.getX() + "  Y = " + e.getY());
    }

    public void mouseDragged(MouseEvent e) {
    }

    public static void main(String[] args) {
        new Mousecoordinates();
    }
}