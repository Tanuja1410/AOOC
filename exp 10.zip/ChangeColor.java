import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ChangeColor extends JFrame implements ActionListener {

    JComboBox box;

    String colors[] = {"Red", "Green", "Blue", "Yellow"};

    ChangeColor() {

        box = new JComboBox(colors);

        box.setBounds(120, 80, 120, 30);

        add(box);

        box.addActionListener(this);

        setTitle("Background Color");
        setSize(400, 300);
        setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        String color = (String) box.getSelectedItem();

        if (color.equals("Red")) {
            getContentPane().setBackground(Color.RED);
        }

        if (color.equals("Green")) {
            getContentPane().setBackground(Color.GREEN);
        }

        if (color.equals("Blue")) {
            getContentPane().setBackground(Color.BLUE);
        }

        if (color.equals("Yellow")) {
            getContentPane().setBackground(Color.YELLOW);
        }
    }

    public static void main(String[] args) {
        new ChangeColor();
    }
}