import java.awt.event.*;
import javax.swing.*;

public class ComboImage extends JFrame implements ItemListener {

    JComboBox box;
    JLabel label;

    String images[] = {"cat.jpg", "dog.jpg"};

    ComboImage() {

        box = new JComboBox(images);

        label = new JLabel();

        box.setBounds(100, 30, 120, 30);

        label.setBounds(50, 80, 300, 200);

        add(box);
        add(label);

        box.addItemListener(this);

        setTitle("Image Viewer");
        setSize(400, 350);
        setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void itemStateChanged(ItemEvent e) {

        String img = (String) box.getSelectedItem();

        ImageIcon icon = new ImageIcon(img);

        label.setIcon(icon);
    }

    public static void main(String[] args) {
        new ComboImage();
    }
}