import java.awt.event.*;
import javax.swing.*;

public class TextCount extends JFrame implements KeyListener {

    JTextArea area;

    JLabel label;

    TextCount() {

        area = new JTextArea();

        label = new JLabel("Characters: 0  Words: 0");

        area.setBounds(50, 50, 300, 120);

        label.setBounds(50, 190, 250, 30);

        add(area);
        add(label);

        area.addKeyListener(this);

        setTitle("Text Counter");
        setSize(400, 300);
        setLayout(null);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void keyReleased(KeyEvent e) {

        String text = area.getText();

        int characters = text.length();

        String words[] = text.trim().split("\\s+");

        int wordCount = text.trim().isEmpty() ? 0 : words.length;

        label.setText("Characters: " + characters +
                "  Words: " + wordCount);
    }

    public void keyPressed(KeyEvent e) {
    }

    public void keyTyped(KeyEvent e) {
    }

    public static void main(String[] args) {
        new TextCount();
    }
}