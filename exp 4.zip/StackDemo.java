// Stack Interface and implementation are in the same folder

// Test Class
public class StackDemo {
    public static void main(String[] args) {

        IntegerStack s = new IntegerStack();

        s.push(10);
        s.push(20);
        s.push(30);
        s.display();

        s.pop();
        s.display();
    }
}
