package MathOperations;

public class Operations {

    public void performOperations(double num) {

        System.out.println("Number: " + num);

        System.out.println("Floor Value: " + Math.floor(num));

        System.out.println("Ceil Value: " + Math.ceil(num));

        System.out.println("Round Value: " + Math.round(num));
    }
}   