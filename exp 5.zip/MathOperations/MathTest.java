import MathOperations.Operations;

public class MathTest {
    public static void main(String[] args) {

        Operations obj = new Operations();

        obj.performOperations(12.7);

        System.out.println();

        obj.performOperations(5.3);
    }
}