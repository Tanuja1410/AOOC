package Ecommerce;

public class customer {
    String customerName;

    public customer(String customerName) {
        this.customerName = customerName;
    }

    public void displayCustomer() {
        System.out.println("Customer Name: " + customerName);
    }
}