import Ecommerce.Product;
import Ecommerce.customer;
import Ecommerce.order;

public class EcommerceTest {
    public static void main(String[] args) {

        Product p1 = new Product("Laptop", 50000);

        customer c1 = new customer("Amit");

        order o1 = new order(2, 50000);

        p1.displayProduct();

        System.out.println();

        c1.displayCustomer();

        System.out.println();

        o1.displayOrder();
    }
}