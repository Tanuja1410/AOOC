package Ecommerce;

public class order {
    int quantity;
    double totalCost;

    public order(int quantity, double price) {
        this.quantity = quantity;
        totalCost = quantity * price;
    }

    public void displayOrder() {
        System.out.println("Quantity: " + quantity);
        System.out.println("Total Cost: " + totalCost);
    }
}