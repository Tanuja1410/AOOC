import LibraryManagement.Book;
import LibraryManagement.Members;

public class LibraryTest {
    public static void main(String[] args) {

        Book b1 = new Book("Java Basics", "James Gosling", "101");

        Members m1 = new Members("Rahul", 1);

        System.out.println("Library Details");
        b1.displayBook();

        System.out.println();

        m1.displayMember();
    }
}