package LibraryManagement;

public class Members {
    String memberName;
    int memberId;

    public Members(String memberName, int memberId) {
        this.memberName = memberName;
        this.memberId = memberId;
    }

    public void displayMember() {
        System.out.println("Member Name: " + memberName);
        System.out.println("Member ID: " + memberId);
    }
}